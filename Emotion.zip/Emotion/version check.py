import scipy as sp
print("scipy 버전 : {}".format(sp.__version__))